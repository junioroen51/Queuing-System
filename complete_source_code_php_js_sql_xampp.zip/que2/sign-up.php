<!DOCTYPE html>
<html lang="en">
<head>
	<title>Hands-on Midterm Exam</title>

	
	<meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="include/bootstrap/css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="include/css/style.css" type="text/css">
    <script src="include/js/jquery.js"></script>
    <script src="include/js/myjquery.js"></script>

</head>

<body>

<head>
  <body>
    <style>
  select[name]{
            background-color: white;
            margin: 20px;
            height: 30px;
            width: 185px;
        }
</style>
<body>

<div align="center">
    <div class="well" align="center" style="border: 2px solid black;">
    <h1 style="color:black;"> CSU Queuing System  </h1>
   <form method="POST" >
    <b>Username:</b>
    <input type="text" name="username" id="username" required><br><br>
    <b>Password :</b>
    <input type="password" name="password" id="password" required><br><br>
    <b>Firstname:</b>
    <input type="text" name="fname" id="fname" required><br><br>
    <b>Lastname :</b>
    <input type="text" name="lname" id="lname" required><br><br>
    <b>Cellphone no. :</b>
    <input type="text" name="cell_no" id="cell_no" required><br><br>
    <b>Course :</b>
    <input type="text" name="course_name" id="course_name" required><br><br>
    <b>Department:</b>
    <input type="text" name="dept_name" id="dept_name" required><br><br>


                  <b> Select Org:</b>
                  <select name="type" id="type_name"  ><br>
                  <option value="Student">Student</option>
                  <option value="Teller">Teller</option>
                  <option value="Admin">Admin</option>
                  </select>

               
</center>
    
    <input id="boton" type="submit" name="submit">
   
  </form>
    </div>


 


    

          <center><b><h3 style="color:floralwhite;padding-top:10px;"><sub>Done register? </sub>   <a style="color:yellow;" href="index.php">Login Now!</a></h3></b></center>

      </form>
    </div>
  </div>


</body>
</html>