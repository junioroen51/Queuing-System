function addToCart() {
        var  pr_name= document.getElementById("pr_name").value;

        var quantity = document.getElementById("quantity").value;    

        var table=document.getElementById("cart");
        var row=table.insertRow(-1);
        var cell1=row.insertCell(0);
        var cell3=row.insertCell(1);

        cell1.innerHTML=pr_name;       
        cell3.innerHTML=quantity;    

        document.getElementById("pr_name").text="";
        document.getElementById("quantity").text="";
    }