<?php
		 $connection = mysqli_connect("localhost","root","","q");


			if (!$connection) {
					   echo "Can't connect to server!";
					 }

?>